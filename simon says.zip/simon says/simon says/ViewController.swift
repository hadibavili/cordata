//
//  ViewController.swift
//  simon says
//
//  Created by hadi tabrizi on 10/28/17.
//  Copyright © 2017 hadi tabrizi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var stratgamebtn: UIButton!
    @IBOutlet weak var scorelabel: UILabel!
    @IBOutlet weak var timerlabel: UILabel!
    @IBOutlet weak var label: UILabel!
    
    
    var timerdigit = 0
    var scoredigit = 0
    var modedigit = 0
    
 var timer  = Timer()
     var simontimer = Timer()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        label.layer.cornerRadius = 30
        label.clipsToBounds = true
        
        timerdigit = 20
        scoredigit = 0
        timerlabel.text = "time: \(timerdigit)"
        scorelabel.text = "score: \(scoredigit)"
        
        self.simonSay()
        
        modedigit = 0
        let swiperight = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.swipeGesture))
        swiperight.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(swiperight)
        
        let swipeleft = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.swipeGesture))
        swipeleft.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(swipeleft)

        let swipeup = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.swipeGesture))
        swipeup.direction = UISwipeGestureRecognizerDirection.up
        self.view.addGestureRecognizer(swipeup)
        
        let swipedown = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.swipeGesture))
        swipedown.direction = UISwipeGestureRecognizerDirection.down
        self.view.addGestureRecognizer(swipedown)
        
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func stratgame(_ sender: Any) {
        
        if timerdigit == 20{
            timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(ViewController.updatetimer), userInfo: nil, repeats: true)
            modedigit = 1
            stratgamebtn.isEnabled = false
         stratgamebtn.alpha = 0.25
            
            modedigit = 1
            

        }
        if timerdigit == 0{
            timerdigit = 20
            timerlabel.text = "time: \(timerdigit)"
            stratgamebtn.setTitle("start Game", for: [])
            label.text = "simon Says "
        }
        
        
    }
    
    
    @objc func updatetimer(){
        timerdigit -= 1
        timerlabel.text = "time: \(timerdigit)"
        if timerdigit == 0{
            timer.invalidate()
            modedigit = 0
            label.text = "Game over"
            stratgamebtn.isEnabled = true
            stratgamebtn.alpha = 1
            stratgamebtn.setTitle("restart", for: [])
            modedigit = 0
            
            
        }
        
        
        

        
    }
    
    
    
    
    
    
    @objc func simonSay(){
        
        
        var array = ["simon say swipe right", "swipe right " , "simon say swipe left", "swipe left " , "simon say swipe up", "swipe up " , "simon say swipe down", "swipe down "]
        
        
        let randomnumber = Int(arc4random_uniform(UInt32(array.count)))
        label.text = array[randomnumber]
        simontimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.simonSay), userInfo: nil, repeats: false)
    }
    
    @objc func swipeGesture(sender: UISwipeGestureRecognizer){
        
        
        if modedigit == 1{
            if sender.direction == .right{
                simontimer.invalidate()
                if label.text == "simon say swipe right"{
                        scoredigit += 1
                    scorelabel.text = "score: \(String(scoredigit))"
                    self.simonSay()
                }else{
                    scoredigit -= 1
                    scorelabel.text = "score: \(String(scoredigit))"
                    self.simonSay()
                }
            }
            
            if sender.direction == .left{
                simontimer.invalidate()
                if label.text == "simon say swipe left"{
                    scoredigit += 1
                    scorelabel.text = "score: \(String(scoredigit))"
                    self.simonSay()
                }else{
                    scoredigit -= 1
                    scorelabel.text = "score: \(String(scoredigit))"
                    self.simonSay()
                }
            }
            
            if sender.direction == .up{
                simontimer.invalidate()
                if label.text == "simon say swipe up"{
                    scoredigit += 1
                    scorelabel.text = "score: \(String(scoredigit))"
                    self.simonSay()
                }else{
                    scoredigit -= 1
                    scorelabel.text = "score: \(String(scoredigit))"
                    self.simonSay()
                }
            }
            
            if sender.direction == .down{
                simontimer.invalidate()
                if label.text == "simon say swipe down"{
                    scoredigit += 1
                    scorelabel.text = "score: \(String(scoredigit))"
                    self.simonSay()
                }else{
                    scoredigit -= 1
                    scorelabel.text = "score: \(String(scoredigit))"
                    self.simonSay()
                }
            }
            
            
            
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

